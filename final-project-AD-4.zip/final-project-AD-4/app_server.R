library(dplyr)
library(shiny)
library(plotly)
source("main.R")

# Define a shiny server in which ... 
server <- function(input, output) {
  # Renders a plotly object that returns the scatter plot
  output$scatter <- renderPlotly({
    return(build_scatter(ev_sales, input$plotvar))
  })
}