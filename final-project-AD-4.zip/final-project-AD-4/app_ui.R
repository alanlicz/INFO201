library(shiny)
library(plotly)
source("main.R")

# Define a variable `scatter_sidebar_content` that is a `sidebarPanel()` for 
# our second (scatter) page that contains:

ui <- navbarPage(
  h1("Electric Vehicles Market Analysis"),
  
  sidebarLayout(
    selectInput(
      "plotvar",
      label = "Model to plot",
      choices = ev_models
    ),
  
    mainPanel(
      tabPanel(
        "test", plotlyOutput("scatter")
      )
    )
  )
)





# Define a variable `scatter_main_content` that is a `mainPanel()` for the
# second (scatter) page that contains the `plotlyOutput()`


# Create a variable `scatter_panel` that stores a `tabPanel()` for the 2nd page
# It should include the following:


# Define a variable `ui` storing a `navbarPage()` element containing
# your two pages defined above
