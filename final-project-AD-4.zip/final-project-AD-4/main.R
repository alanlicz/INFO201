library(plotly)
library(dplyr)
library(stringr)

df <- readr::read_csv("./data/EV_sales_by_model.csv")

# Get all the rows in the file except for the last row
df <- df[1:55, ]

# Filter the dataset to contain only the sales of electrical vehicles
ev_sales <- df %>%
  filter(Type == "EV")
ev_sales <- subset(ev_sales, select = -c(Type, Total))

# Get all the model names
ev_models <- ev_sales[["Vehicle"]]


### Build Scatter ###
build_scatter <- function(data, model) {
  data.sales <- 
    ev_sales %>%
    filter(Vehicle == model) %>%
    gather("year", "sales", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019")
  # plot the data
  data.sales$sales2 <- as.numeric(gsub(",", "", data.sales$sales))

  p <-
    ggplot(data = data.sales, aes(x=year, y=sales2, text=paste(sales2, Vehicle))) +
    geom_bar(stat="identity")
  return(ggplotly(p, tooltip = "text"))
}




